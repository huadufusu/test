<template>
  <div>
    <el-container>
        <el-header height="auto">        
          <el-upload
            class="upload-demo"
            drag
            accept="file/tar,file/zip,file/gz,file/rar"
            action="https://jsonplaceholder.typicode.com/posts/"            
            multiple>
            <i class="el-icon-upload"></i>
            <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
            <div class="el-upload__tip" slot="tip">只能上传类型为tar、zip、gz、rar等压缩格式文件，且不超过2G</div>
          </el-upload> 
        </el-header>
        <el-main>
          <el-table
            ref="multipleTable"
            :data="tableData3.slice((currentPage-1)*pagesize,currentPage*pagesize)"  
            tooltip-effect="dark"
            height:auto
            border
            style="width: 100%">
            <el-table-column
              prop="taskId"
              label="上传人用户ID"
              width="180">
            </el-table-column>
            <el-table-column
              prop="fileName"
              label="文件名称"
              width="180">
            </el-table-column>
            <el-table-column
              prop="fileSize"
              label="文件大小 (bit) "
              width="180">
            </el-table-column>
            <el-table-column
              prop="uploadTime"
              label="上传时间"
              width="180"> 
            </el-table-column>
            <el-table-column
              prop="result"
              label="结果"
              width="180"> 
            </el-table-column>
            <el-table-column
              prop="remark"
              label="评论"> 
            </el-table-column>
          </el-table>
          <div style="text-align: center;margin-top: 30px;">
            <el-pagination
              background
              layout="prev, pager, next, sizes, total, jumper"  
              :page-sizes="[10]"             
			        :page-size="pagesize"
              :total="tableData3.length"
              @current-change="handleCurrentChange"
              @size-change="handleSizeChange">
            </el-pagination>
        </div>
        </el-main>          
     </el-container>
  </div>
</template>

<script>
/* eslint-disable */
// eslint-disable-next-line
import axios from 'axios'
import { Loading } from 'element-ui'
export default {
  data () {
    return {
      total: 0,
      pagesize:10,
      currentPage:1,
      tableData3: [{
        taskId: 95597,
        fileName: "a.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      }, {
        taskId: 95596,
        fileName: "b.txt",
        fileSize: "102411",
        uploadTime: "2018-12-27 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId:95599,
        fileName: "c.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId:95598,
        fileName: "d.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId: 95591,
        fileName: "d.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId: 95598,
        fileName: "d.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId: 95598,
        fileName: "d.txt",
        fileSize: "10241021", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      },{
        taskId: 95598,
        fileName: "d.txt",
        fileSize: "10241022", 
        uploadTime: "2018-12-28 12:00:00",
        result: "ok",
        remark: "xxxxxxxxx"
      }]  
    }
  },
  methods: {    
    getUrlList () {
      let loadingInstance = Loading.service({ fullscreen: true, text: '加载中' })
      let t = Math.random()
      let host = window.location.host.toString()
      let url = 'urlListOa.json'
      if (host === '20.16.15.10:88') {
        url = 'urlListOa.json'
      } else if (host === '144.16.15.10:88') {
        url = 'urlListPit.json'
      } else {
        url = 'urlListOa.json'
      }
      axios.get('static/' + url + '?t=' + t).then((response) => {
        if (response.status === 200) {
          this.urlList = response.data.params
          console.log(response.data.params)
          loadingInstance.close()
        }
      }).catch(function (err) {
        console.error(err)
      })
    },  
    handleCurrentChange:function(currentPage){
      this.currentPage = currentPage;
    },  
    handleSizeChange:function(pagesize){
      this.pagesize = pagesize;
    }, 
    mounted () {
    },
    beforeMount () {
    }  
  }
}
</script>

<style scoped>
  .el-container{
    font-size: 14px;
  }
  .el-header {
    line-height: 60px;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    
  }
  .el-main {
    background-color: #FFFFFF;
  }
  .info{
    margin-bottom: 2rem;
  }
  .main{
    width: 60rem;
    height: auto;
    margin: 0 auto;
    border: 1px solid #F4F4F5;
  }
</style>
