<template>
  <div>
    <el-container>
      <el-header height='auto'>
        <el-upload
          class='upload-demo'
          drag
          action='http://192.168.137.172:8080/cop-web/change/uploadFiletg'
          multiple>
          <i class='el-icon-upload'></i>
          <div class='el-upload__text'>将文件拖到此处，或<em>点击上传</em></div>
          <div class='el-upload__tip' slot='tip'>只能上传类型为tar、zip、gz、rar等压缩格式文件，且不超过2G</div>
        </el-upload>
      </el-header>
      <el-main>
        <el-table
          ref='multipleTable'
          :data='tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)'
          tooltip-effect='dark'
          height:auto
          width:auto>
          <el-table-column
            prop='id'
            label='任务id'
            width='180'>
          </el-table-column>
          <el-table-column
            prop='filename'
            label='文件名称'
            width='180'>
          </el-table-column>
          <el-table-column
            prop='filesize'
            label='文件大小 (bit) '
            width='180'>
          </el-table-column>
          <el-table-column
            prop='uploadtime'
            label='上传时间'
            width='180'>
          </el-table-column>
          <el-table-column
            prop='result'
            label='结果'
            width='180'>
          </el-table-column>
          <el-table-column
            prop='userid'
            label='用户id'
            width='180'>
          </el-table-column>
        </el-table>
        <div style='text-align: center;margin-top: 30px;'>
          <el-pagination
            background
            layout='prev, pager, next, sizes, total, jumper'
            :page-sizes='[pagesize]'
            :page-size='pagesize'
            :total='tableData.length'
            @current-change='handleCurrentChange'
            @size-change='handleSizeChange'>
          </el-pagination>
        </div>
      </el-main>
     </el-container>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data () {
    return {
      total: 0,
      pagesize: 10,
      currentPage: 1,
      tableData: []
    }
  },
  created () {
    this.getResList()
    this.doPost()
  },
  methods: {
    getResList () {
      axios.get('/v1/cop-web/change/getuphistory', {
        params: {
          page: this.currentPage,
          rows: this.pagesize,
          userid: '01204206'
        }
      }).then((response) => {
      //  axios.get('/v1/cop-web/change/getuphistory?page=1&rows=10')
      //  .then((response) => {
        if (response.status === 200) {
          this.total = response.data.total
          this.currentPage = response.data.page //  当前页
          this.pagesize = 1 // 每页条数，别忘记修改rows
          this.tableData = response.data.rows
          console.log(response.data)
        }
      }).catch(function (err) {
        console.error(err)
      })
    },
    handleCurrentChange: function (currentPage) {
      this.currentPage = currentPage
    },
    handleSizeChange: function (pagesize) {
      this.pagesize = pagesize
    },
    doPost () {
      console.log('update')
      let data = {
        userid: '1'
      }
      axios({
        method: 'POST',
        url: '/v1/cop-web/change/getuphistory1',
        data: data,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      })
        .then(function (response) {
          console.log(response.data)
        })
        .catch(function (error) {
          console.log(error)
        })
    }
  },
  mounted () {
  },
  beforeMount () {
  }
}
</script>

<style scoped>
  .el-container {
    font-size: 14px;
  }
  .el-header {
    line-height: 20px;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  .el-main {
    background-color: #FFFFFF;
  }
  .el-table {
    margin-left: 5rem;
    margin-right: 5rem;
    width:auto;
  }
  .info {
    margin-bottom: 2rem;
  }
  .main {
    width: 60rem;
    height: auto;
    margin: 0 auto;
    border: 1px solid #F4F4F5;
  }
</style>
